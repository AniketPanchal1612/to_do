
import { v4 } from "uuid";
const data =[{
    id:'2264526e-0a86-4bbc-b23f-8d75fd11416d',
    boardName: "Earth Changes and Journeys",
    boardColor:'#ade8f4'
},
{
    id:v4(),
    boardName: "Eating Right",
    boardColor:'#a3b18a'
}
]

export default data;