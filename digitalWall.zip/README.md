# Getting Started with Create React App

# install modules and then start react app 

# 1 -> npm i
# 2 -> npm start
